from __future__ import unicode_literals

from django.db import models


class Cart(models.Model):
    id = models.CharField(primary_key=True, max_length=255)

    class Meta:
        db_table = 'cart'


class Shop(models.Model):
    id = models.CharField(primary_key=True, max_length=255)
    name = models.CharField(max_length=255)
    level = models.IntegerField()

    class Meta:
        db_table = 'shop'


class Item(models.Model):
    id = models.CharField(primary_key=True, max_length=255)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    name = models.CharField(max_length=255)
    shopid = models.ForeignKey('Shop')

    class Meta:
        db_table = 'item'


class CartItemRelation(models.Model):
    cartid = models.ForeignKey('Cart')
    itemid = models.ForeignKey('Item')

    class Meta:
        db_table = 'cart_item_relation'


class Order(models.Model):
    id = models.CharField(primary_key=True, max_length=255)
    date = models.DateTimeField()
    buyer = models.ForeignKey('User', related_name="custom_user_buyer")
    seller = models.ForeignKey('User', related_name="custom_user_seller")

    class Meta:
        db_table = 'order'


class OrderItemRelation(models.Model):
    id = models.CharField(primary_key=True, max_length=255)
    orderid = models.ForeignKey(Order)
    itemid = models.ForeignKey(Item)

    class Meta:
        db_table = 'order_item_relation'


class Roles(models.Model):
    id = models.CharField(primary_key=True, max_length=255)
    name = models.CharField(max_length=255)
    power = models.IntegerField()

    class Meta:
        db_table = 'roles'


class ShopItemRelation(models.Model):
    shopid = models.ForeignKey(Shop)
    itemid = models.ForeignKey(Item)

    class Meta:
        db_table = 'shop_item_relation'


class User(models.Model):
    id = models.CharField(primary_key=True, max_length=255)
    account = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    gender = models.IntegerField()
    age = models.IntegerField()
    idcode = models.CharField(max_length=255)
    rolesid = models.ForeignKey(Roles)
    email = models.CharField(max_length=255)
    credit = models.CharField(max_length=255, blank=True, null=True)
    tel = models.CharField(max_length=255)
    address = models.CharField(max_length=255, blank=True, null=True)
    cartid = models.ForeignKey(Cart)
    shopid = models.ForeignKey(Shop, blank=True, null=True)

    class Meta:
        db_table = 'user'
