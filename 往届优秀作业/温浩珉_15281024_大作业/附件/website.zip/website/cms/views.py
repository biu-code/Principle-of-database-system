from django.shortcuts import render
from django.http import HttpResponse
from django.http import HttpResponseRedirect
import datetime
import time
from . import models


lo = False
u = 'Any'
l = {'login': lo, 'user': u}  # 登陆状态

user = {}  # 当前登陆用户
li = {}


def index(request):
    return render(request, "index.html", l)


def login(request):
    return render(request, "login.html")


def logout(request):
    l['login'] = False
    l['user'] = 'Any'
    return render(request, "index.html", l)


def checkuser(request):
    acc = request.POST['account']
    pwd = request.POST['password']

    u = models.User.objects.filter(account=acc)

    if u and u[0].password == pwd:
        l['login'] = True
        l['user'] = u[0].account
        user['id'] = u[0].id
        user['account'] = u[0].account
        user['name'] = u[0].name
        user['gender'] = u[0].gender
        user['age'] = u[0].age
        user['idcode'] = u[0].idcode
        user['email'] = u[0].email
        user['credit'] = u[0].credit
        user['tel'] = u[0].tel
        user['address'] = u[0].address
        #class
        user['cartid'] = u[0].cartid
        user['roleid'] = u[0].rolesid
        user['shopid'] = u[0].shopid
    return render(request, "index.html", l)


def search(request):
    item = request.POST['item']
    i = models.Item.objects.filter(name=item)
    if i:
        #print(i[0].shopid.name)
        li['item'] = i
        li['login'] = l['login']
        li['user'] = l['user']
        #print(i[0].shopid_id)
    return render(request, "index.html", li)


def buy(request):
    item_id = request.GET.get('id')  # 获取url参数得到商品ID
    item = models.Item.objects.filter(id=item_id)
    # print("item",len(item))
    if l['login']:
        t = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        order_id=str(int(time.time() * 1000))
        # 生成订单信息
        order = models.Order(order_id, t,user['id'], item[0].shopid.user_set.all()[0].id)
        order.save()

        #生成订单-商品信息
        order_item_id=str(int(time.time() * 100))
        order_item=models.OrderItemRelation(order_item_id,order_id,item_id)
        order_item.save()
        order_res_=[order_res(user["address"],t,item[0].price,item[0].shopid.name)]
        return render(request, "order.html",{"orders":order_res_})
    else:
        return HttpResponseRedirect("../login")


def add_cart(request):
    item_ = request.GET.get('id')
    item = models.Item.objects.filter(id=item_)
    if l['login']:
        #return HttpResponse(user['cartid'])
        cart = models.CartItemRelation(cartid =user['cartid'] , itemid = item[0])
        cart.save()
        return render(request, "cart.html")
    else:
        return HttpResponseRedirect("../login")
    #return HttpResponse(item_)

def show_cart(request):
    cart_id=user["cartid"].id
    # print("cart id:",cart_id)
    res=models.CartItemRelation.objects.filter(cartid_id=cart_id)
    item_ids=[r.itemid_id for r in res ]
    print("item_ids",item_ids)
    items=[models.Item.objects.filter(id=item_id)[0] for item_id in item_ids]
    # print("type of items:",items)
    # print("items",items)
    return render(request, "cart.html",{"item":items})

class order_res:
    def __init__(self,address_="",date_="",price_=0,shopname=""):
        self.address=address_
        self.date=date_
        self.price=price_
        self.shop_name=shopname

def show_order(request):
    orders=models.Order.objects.filter(buyer_id=user['id'])

    order_res_=[]
    for order in orders:
        address_= user["address"]
        date_= order.date

        item_id=models.OrderItemRelation.objects.filter(orderid_id=order.id)[0].itemid_id
        item=models.Item.objects.filter(id=item_id)[0]
        price_=item.price

        seller=models.User.objects.filter(id=order.seller_id)[0]
        shopid=seller.shopid_id
        shopname=models.Shop.objects.filter(id=shopid)[0].name
        order_res_.append(order_res(address_,date_,price_,shopname))

    # orders = [ order_res(str(i)) for i in range(4)]
    return render(request, "order.html",{"orders":order_res_})

